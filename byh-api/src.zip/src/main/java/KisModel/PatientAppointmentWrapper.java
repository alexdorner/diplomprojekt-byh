package KisModel;

import java.util.Set;

public class PatientAppointmentWrapper {

    public PatientAppointmentK data;

    public PatientAppointmentK getData() {
        return data;
    }

    public void setData(PatientAppointmentK data) {
        this.data = data;
    }

}
