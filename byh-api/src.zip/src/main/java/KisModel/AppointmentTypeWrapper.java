package KisModel;

import java.util.Set;

public class AppointmentTypeWrapper {
    public AppointmentTypeK getData() {
        return data;
    }

    public void setData(AppointmentTypeK data) {
        this.data = data;
    }

    AppointmentTypeK data;
}
