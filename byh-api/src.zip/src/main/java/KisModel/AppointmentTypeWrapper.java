package KisModel;

import java.util.Set;

public class AppointmentTypeWrapper {
    public Set<AppointmentTypeK> getData() {
        return data;
    }

    public void setData(Set<AppointmentTypeK> data) {
        this.data = data;
    }

    Set<AppointmentTypeK> data;
}
