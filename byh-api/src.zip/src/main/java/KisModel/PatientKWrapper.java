package KisModel;

public class PatientKWrapper {

    public PatientK getData() {
        return data;
    }

    public void setData(PatientK data) {
        this.data = data;
    }

    PatientK data;
}
