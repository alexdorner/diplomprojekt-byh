package KisModel;

public class CompanyWrapper {
    public Company getData() {
        return data;
    }

    public void setData(Company data) {
        this.data = data;
    }

    public Company data;

}
