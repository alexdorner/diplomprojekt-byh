package KisModel;

public class ServiceUnitWrapper {

    public ServiceUnit getData() {
        return data;
    }

    public void setData(ServiceUnit data) {
        this.data = data;
    }

    public ServiceUnit data;
}
