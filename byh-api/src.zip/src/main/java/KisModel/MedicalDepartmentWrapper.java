package KisModel;

public class MedicalDepartmentWrapper {

    public MedicalDepartmentK getData() {
        return data;
    }

    public void setData(MedicalDepartmentK data) {
        this.data = data;
    }

    public MedicalDepartmentK data;
}
