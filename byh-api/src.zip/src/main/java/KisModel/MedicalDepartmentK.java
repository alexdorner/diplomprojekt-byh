package KisModel;

public class MedicalDepartmentK {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    //Medical Department
 public String name;




}
