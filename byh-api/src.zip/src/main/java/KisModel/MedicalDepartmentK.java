package KisModel;

public class MedicalDepartmentK {
    //service Unit
 public String kis_service_unit_name;
 public String service_unit_type;
 public String allow_appointments;

    public String getKis_service_unit_name() {
        return kis_service_unit_name;
    }

    public void setKis_service_unit_name(String kis_service_unit_name) {
        this.kis_service_unit_name = kis_service_unit_name;
    }

    public String getService_unit_type() {
        return service_unit_type;
    }

    public void setService_unit_type(String service_unit_type) {
        this.service_unit_type = service_unit_type;
    }

    public String getAllow_appointments() {
        return allow_appointments;
    }

    public void setAllow_appointments(String allow_appointments) {
        this.allow_appointments = allow_appointments;
    }


}
