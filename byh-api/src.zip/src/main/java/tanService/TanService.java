package tanService;

public interface TanService {
	public int getTan(String sessionID);
}
