package mailService;

import Model.MailConfigModel;

public interface MailConfig {
	public MailConfigModel getMailConfig();
}
