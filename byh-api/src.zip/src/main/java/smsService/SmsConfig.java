package smsService;

import Model.SmsConfigModel;

public interface SmsConfig {
	public SmsConfigModel getSmsConfig();
}
