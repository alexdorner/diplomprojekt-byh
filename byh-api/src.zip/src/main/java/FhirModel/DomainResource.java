package FhirModel;

public class DomainResource extends Resource{
}
