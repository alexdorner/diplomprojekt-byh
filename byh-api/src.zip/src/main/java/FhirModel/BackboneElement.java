package FhirModel;

public class BackboneElement extends Element{
}
