import React, { Component } from 'react';

class Contact extends Component {
    render() {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 30 }}>
                <div><h2>Contact Page</h2>
                </div>
            </div>
        );
    }
}

export default Contact;