import React, { Component } from 'react';

class Impressum extends Component {
    render() {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 30 }}>
                <div><h2>Impressum</h2>
                </div>
            </div>
        );
    }
}

export default Impressum;